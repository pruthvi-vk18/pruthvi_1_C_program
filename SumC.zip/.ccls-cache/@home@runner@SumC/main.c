#include <stdio.h>
int main ()
{
  int a,b,sum;
  printf("enter the two numbers:");
  scanf("%d%d",&a,&b);
  sum=a+b;
  printf("sum=%d\n",sum);
  return 0;
}

